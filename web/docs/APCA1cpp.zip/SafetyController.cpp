
#include "SafetyController.h"
#include <math.h>


CSafetyController::CSafetyController(void)
{
    braking = 0;
    readyBrake = 0;
    maxBraking = 0;
    standardBrake = -.25*9.81;
    maxBrake = -.85*9.81;
    maxSpeed = 13.9;
    maxAccel = .25*9.81;
    
    
}


CSafetyController::~CSafetyController(void)
{
}


void CSafetyController::apcaAlgo(bool m_pedExists, double m_pedX, double m_pedY, double m_pedSpeed)
{
    
    //Determine how long it will take for the vehicle to reach the collision zone.
    double timeAway = m_pedX / speed; //t = d/r
    
    //Determine the soonest time that the vehicle can reach the collision zone
    if(speed < maxSpeed)
    {
        //determine how long it will take to reach the vehicles steady state velocity
        double timeToMaxSpeed = (maxSpeed - speed) / maxAccel; //t = (vf - vi) / a
        
        if(timeToMaxSpeed < timeAway) //if maxspeed can be reached before collision zone
        {
            //determine how much distance was covered in that time
            //d = vi*t + (a*t^2)/2
            double distanceWhileAccel = speed * timeToMaxSpeed + maxAccel * timeToMaxSpeed * timeToMaxSpeed / 2;
        
            //determine remaining distance
            double remainingDistance = m_pedX - distanceWhileAccel;
        
            //determine how long it will take to cover the remaining distance
            double timeAtMaxSpeed = remainingDistance / maxSpeed;
        
            //determine fastest time vehicle can reach the collision zone
            timeAway = timeToMaxSpeed + timeAtMaxSpeed;
        }
        else
        {
            //determine the max velocity of the vehicle at the collision zone
            double vf = sqrt(speed * speed + 2 * maxAccel * m_pedX);
            
            //determine average velocity
            double vAvg = (speed + vf) / 2;
            
            //determine the time it will take to reach collision zone
            timeAway = m_pedX / vAvg;
        }
    }
    
    //Determine if its possible for the pedestrian to be in the collision zone when the vehicle gets there
    bool CollisionPossible = (2.8 * timeAway) + m_pedY >= -1.75 && m_pedY <= 1.75 && m_pedX > 0;

    if (!braking) //if the brake is not currently being applied
    {        
        if (CollisionPossible) //collision possible will always occur before maxBrake needs to be applied
        {
            BBW->applyBrakes(standardBrake);
            braking = 1;
        }
    }
    
    else
    {
        //Standard brake is applied untill (!Collision) or must stop
        if(!CollisionPossible)
        {
            BBW->releaseBrakes();
            braking = 0;
            maxBraking = 0;
        }
        
        else if(!maxBraking) //if already maxBraxing no need to check
        {
            //find speed two frames ahead
            double speedInTwo = speed + standardBrake * .2;
            
            //find distance from ped in two frames
            double pedInTwo = m_pedX - (speed * .2 + .2 * .2 * maxBrake / 2);
            
            //Determine if two frames from now it will be possible to stop before the ped
            double vfInTwo = speedInTwo * speedInTwo + 2 * maxBrake * pedInTwo;
       
            //if it will be impossible to stop two frames from now, stop now
            if(vfInTwo > 0)
            {
                BBW->applyBrakes(maxBrake);
                maxBraking = 1;
            }
        }
    }
        
}

void CSafetyController::reset(void)
{
    braking = 0;
    readyBrake = 0;
    maxBraking = 0;
}

void CSafetyController::setBBW(CBrakeByWire* m_BBW)
{
	BBW = m_BBW;
}

void CSafetyController::setSpeed(double m_speed)
{
    speed = m_speed;
}
