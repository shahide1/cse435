
#ifndef SAFETYCONTROLLER_H_
#define SAFETYCONTROLLER_H_

#include <iostream>
#include "BrakeByWire.h"

using namespace std;

class CSafetyController
{
public:
	CSafetyController(void);
	virtual ~CSafetyController(void);
	
	void apcaAlgo(bool m_pedExists, double m_pedX, double m_pedY, double m_pedSpeed);
	void setBBW(CBrakeByWire*);
    void setSpeed(double);
    void reset(void);
    

private:
	CBrakeByWire* BBW;
    double speed;
    double readyBrake;
    bool braking;
    double standardBrake;
    double maxBrake;
    bool maxBraking;
    double maxSpeed;
    double maxAccel;


};

#endif