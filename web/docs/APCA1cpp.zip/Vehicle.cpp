
#include "Vehicle.h"


CVehicle::CVehicle(void)
{
    time = 0;
    speed = 0;
    v_x = 0;
    v_y = 0;
    collision = 0;
    i = 0;
    pastPed = 0;
    
}


CVehicle::~CVehicle(void)
{
}


void CVehicle::setDrive(void)
{
	enable();
    speed = 13.9;
}


void CVehicle::setPark(void)
{
	disable();
    speed = 0;
}

double CVehicle::getAccel(void)
{
    if (speed == 0) 
    {
        return 0;
    }
    
    else if (BBW.isActive()) 
    {
        return BBW.getBrake();
    }
    else
    {
        if (speed < 13.9)
        {
            return (.25 * 9.81);
        }

        else
        {
            return 0;
        }

    }
}

void CVehicle::gasPedal(void)
{
	disable();
}


void CVehicle::steeringWheel(void)
{
	disable();
}


void CVehicle::brakePedal(void)
{
	disable();
}


void CVehicle::enable(void)
{
	time = 0;
    v_x = 0;
    PDS.setSC(&SC);	
	SC.setBBW(&BBW);

}


void CVehicle::disable(void)
{
    //in disable
}

void CVehicle::reset(void)
{
    SC.reset();
    BBW.reset();
    pastPed = 0;
    collision = 0;
    i = 0;
    
}


void CVehicle::alert(void)
{
    cout<<"In alert()\n";
}

void CVehicle::advanceTime(bool m_pedExists, double m_pedX, double m_pedY, double m_pedSpeed)
{
    time+=.05;
    
    if(PDS.isMalfunction())
	{
		alert();
	}
    
    SC.setSpeed(speed);
    
    if(i%2 == 0)
    {
        PDS.readData(m_pedExists, m_pedX, m_pedY, m_pedSpeed);
    }
    
    if (BBW.isStarted())
    {
        BBW.incTime();
    }
    
    if (BBW.isActive()) 
    {
        speed += BBW.getBrake() * .05; 
    }
    
    else
    {
        if (speed < 13.9)
        {
            speed += (.25 * 9.81) * .05;
        }
    }
    
    if (speed < 0) 
    {
        speed = 0;
    }
    
    if (speed > 13.9) 
    {
        speed = 13.9;
    }
    
    v_x += .05 * speed; //update vehicle's location based on it's speed
    
    
    
    if (m_pedX <=0 && pastPed == 0)
    {
        pastPed = 1;
        
        if(m_pedY <=1.75 && m_pedY >= -1.75)
        {
            collision = 1;
        }
        
    }
 
    i++;
}
