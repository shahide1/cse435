
#include "Sensor.h"


CSensor::CSensor(void)
{
	malfunction = 0;
}


CSensor::~CSensor(void)
{
}


void CSensor::readData(bool m_pedExists, double m_pedX, double m_pedY, double m_pedSpeed)
{
    pedExists = m_pedExists;
    pedX = m_pedX;
    pedY = m_pedY;
    pedSpeed = m_pedSpeed;
    sendData();
}


void CSensor::sendData(void)
{
	SC->apcaAlgo(pedExists, pedX, pedY, pedSpeed);
}


bool CSensor::isMalfunction(void)
{
	return malfunction;
}


void CSensor::setSC(CSafetyController* m_SC)
{
	SC = m_SC;
}

