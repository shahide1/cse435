
#include "BrakeByWire.h"


CBrakeByWire::CBrakeByWire(void)
{
    brake = 0;
    brakeActive = 0;
    brakeStarted = 0;
    time = 0;
}


CBrakeByWire::~CBrakeByWire(void)
{
}


void CBrakeByWire::applyBrakes(double m_brake)
{
    brake = m_brake;
    brakeStarted = 1;
}

void CBrakeByWire::incTime(void)
{
    time++;
    if (time==3) 
    {
        brakeActive = 1;
        brakeStarted = 0;
    }
}

void CBrakeByWire::releaseBrakes()
{
    brakeActive = 0;
}

void CBrakeByWire::reset(void)
{
    brake = 0;
    brakeActive = 0;
    brakeStarted = 0;
    time = 0;
}