//
//  APCA.cpp
//  
//
//  Created by David Culham on 11/19/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#include <iostream>
#include <iomanip>
#include <string>

#include "Vehicle.h"

using namespace std;

int main(int argc, char *argv[])
{
    CVehicle v;
    
    string scenario;
    
    for(;;)
    {
        v.setDrive();
        
        bool pedExists = 1;
        double pedX = 35;
        double pedSpeed = 0;
        
        
        double pedY;
        double pedYEnd;
        double pedBegin;
        
        bool stop = 1;
        bool skip = 0;
        bool moves = 1;
        
        
        //Select Scenario////////////////
        
        cout<<"Select Scenario: ";
        cin>>scenario;
        
        if(scenario=="end" || scenario=="break" || scenario == "exit")
        {
            break;        
        }
    
        if(scenario == "1")
        {
            pedY = -7;
            pedYEnd = 0;
            pedBegin = 0;
        }
        
        else if(scenario == "2")
        {
            pedY = -7;
            pedYEnd = -2;
            pedBegin = 0;
        }
        
        else if(scenario == "3")
        {
            pedY = -7;
            pedYEnd = -3;
            pedBegin = 0;
        }

        else if(scenario == "4")
        {
            pedY = -7;
            pedYEnd = -5;
            pedBegin = 0;
        }

        else if(scenario == "5")
        {
            pedY = 0;
            pedBegin = 1.5;
            stop = 0;
        }
        
        else if(scenario == "6")
        {
            pedY = -2;
            pedBegin = 1.8;
            stop = 0;
        }
        
        else if(scenario == "7")
        {
            pedY = -4;
            pedBegin = 1.1;
            stop = 0;
        }
        
        else if(scenario == "8")
        {
            pedY = 0;
            moves = 0;
        }
        
        else if(scenario == "9")
        {
            pedY = -2;
            moves = 0;
        }
        
        else if(scenario == "10")
        {
            pedY = -4;
            moves = 0;
        }

        else
        {
            cout<<"Invalid selection\n";
            skip = 1;
        }
        
        //Display Scenario Selected/////////////
        
        cout<<endl<<"***********SCENARIO "<<scenario<<"***********\n";
        cout<<"Pedestrian Initial Position: "<<pedY<<endl;
        cout<<"Pedestrian End Position: ";
        if (pedBegin > 0) {cout<<"Does Not Stop";}
        else {cout<<pedYEnd;}
        cout<<endl;
        
        cout<<"Pedestrian Time Before Moving: "<<pedBegin<<endl;
        
        cout<<"Pedestrian Initial Speed: ";
        if (pedBegin > 0) {cout<<0;}
        else {cout<<2.8;}
        cout<<endl;
        
        cout<<"Pedestrian Final Speed: ";
        if (pedBegin > 0) {cout<<2.8;}
        else {cout<<0;}
        cout<<endl<<endl;
        
        cout<<"Time  PedX   CarX   PedY  CarY  PedSpeed  CarSpeed  Acceleration\n";
        
        while (v.getTime() < 5. && !skip)
        {
            
            if (pedBegin - v.getTime() <= .001 && pedBegin - v.getTime() >= -.001 && moves)  //pedestrian starts moving
            {
                pedSpeed = 2.8;
            }
            
            v.advanceTime(pedExists, pedX - v.getX(), pedY, pedSpeed); //increment time 
            
            pedY += pedSpeed * .05; //increment pedY
            
            if(pedY >= pedYEnd && stop) //pedestrian stops moving
            {
                pedY = pedYEnd;
                pedSpeed = 0;
            }

            cout<<setw(4)<<setprecision(2)<<fixed<<v.getTime();
            cout<<setw(6)<<setprecision(0)<<pedX;
            cout<<setw(7)<<setprecision(2)<<v.getX();
            cout<<setw(7)<<setprecision(2)<<pedY;
            cout<<setw(6)<<setprecision(0)<<v.getY();
            cout<<setw(10)<<setprecision(2)<<pedSpeed;
            cout<<setw(10)<<setprecision(2)<<v.getSpeed();
            cout<<setw(14)<<setprecision(2)<<v.getAccel();
            cout<<endl;
            
        }

        v.reset();
    }
    

    
}
