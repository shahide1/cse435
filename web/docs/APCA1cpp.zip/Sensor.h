#ifndef SENSOR_H_
#define SENSOR_H_

#include "SafetyController.h"

class CSensor
{
public:
	CSensor(void);
	virtual ~CSensor(void);

	void readData(bool, double, double, double);
	void sendData(void);
	bool isMalfunction(void);

	void setSC(CSafetyController*);

private:
	bool pedExists;
	double pedX;
	double pedY;
	double pedSpeed;

	bool malfunction;

	CSafetyController* SC;
};

#endif
