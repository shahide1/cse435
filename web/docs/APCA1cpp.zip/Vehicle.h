
#include "Sensor.h"
#include "SafetyController.h"
#include "BrakeByWire.h"

class CVehicle
{
public:
	CVehicle(void);
	~CVehicle(void);

	void setDrive(void);
	void setPark(void);
	void gasPedal(void);
	void steeringWheel(void);
	void brakePedal(void);
	void enable(void);
	void disable(void);
	void alert(void);
    void advanceTime(bool, double, double, double);
    void reset(void);
    
    double getTime(){return time;}
    double getSpeed(){return speed;}
    double getAccel(void);
    
    double getX(){return v_x;}
    double getY(){return v_y;}

private:
	CSensor PDS;
	CSafetyController SC;
	CBrakeByWire BBW;
    
    double time;  // s
    double speed; // m/s
    double v_x;   // m
    double v_y;   // m
    unsigned i;
    
    bool collision;
    bool pastPed;
};

