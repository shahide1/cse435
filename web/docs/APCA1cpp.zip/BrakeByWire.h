
#ifndef BRAKEBYWIRE_H_
#define BRAKEBYWIRE_H_

#include <iostream>
using namespace std;

class CBrakeByWire
{
public:
	CBrakeByWire(void);
	virtual ~CBrakeByWire(void);
	
	void applyBrakes(double);
    void releaseBrakes(void);
    double getBrake(void){return brake;}
    void incTime(void);
    void reset(void);
    bool isActive(void){return brakeActive;}
    bool isStarted(void){return brakeStarted;}
	

private:
    double brake;
    int time; //time * .05
    bool brakeActive;
    bool brakeStarted;
	
};

#endif